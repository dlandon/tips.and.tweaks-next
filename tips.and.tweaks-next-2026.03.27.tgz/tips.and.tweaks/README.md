**Tips and Tweaks - Next**

This plugin allows you to adjust selected Linux kernel and system settings that may improve the performance of your Unraid server.

Changes made by the plugin take effect immediately. If the plugin is removed, the last applied settings remain in effect until the server is rebooted.

Originally developed and maintained by Dan Landon.

Project repository, documentation, and license information are available on GitHub.
