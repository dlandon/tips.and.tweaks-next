<?php
/*
Copyright (C) 2016-2026 Dan Landon
Licensed under the Tips and Tweaks - Next Personal Use License v1.0
See LICENSE.md for full license terms.
*/

$allowed_actions = [
	'flow',
	'offload',
	'rx_buffer',
	'tx_buffer',
	'vm_dirty',
	'vm_background',
	'vm_dirty_writeback',
	'vm_dirty_expire',
	'current_user_watches',
	'max_user_instances',
	'max_smb_files',
	'cpu_governor',
	'get_boost',
];

$action		= $_POST['action'] ?? "";
$result	= "* unknown *";

if (in_array($action, $allowed_actions, true)) {
	$cmd	= "/usr/local/emhttp/plugins/tips.and.tweaks/scripts/rc.tweaks ".escapeshellarg($action);
	$result	= trim(shell_exec($cmd) ?? "");
}

header("Content-Type: text/plain");
echo $result;
?>
